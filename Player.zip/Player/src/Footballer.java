import java.util.ArrayList;

public class Footballer {

    private int footID;
    private String name;
    private int age;
    private Position pos;
    private double price;
    private boolean purchased = false;

    protected static ArrayList<Footballer> allFootballers = new ArrayList<Footballer>();

    public Footballer(int footID, String name, int age, String pos, double price) {
        setID(footID);
        setName(name);
        setAge(age);
        setPos(pos);
        setPrice(price);
    }

    private void setID(int footID) {
        if (footID >= 1) {
            this.footID = footID;
        }
    }

    private void setName(String name) {
        if (name != null) {
            this.name = name;
        }
    }

    private void setAge (int age) {
        if (age > 0) {
            this.age = age;
        }
    }

   private void setPos(String p) {
        if (p == "defender") {
            pos = Position.DEFENDER;
        }

        else if (p == "midfilder") {
            pos = Position.MID_FILDER;
        }
        else if (p == "attacker") {
            pos = Position.ATTACKER;
        }
   }

   protected void setPrice(double price) {
        this.price = price;
   }

   protected void setPurchase(boolean purchase) {
        this.purchased = purchase;
   }

   public int getFootID() {
        return this.footID;
   }
   public String getName() {
        return this.name;
   }

   public int getAge() {
        return this.age;
   }

   public Position getPos() {
        return this.pos;
   }

   public Double getPrice() {
        return this.price;
   }

   public boolean getPurchase() {
        return this.purchased;
   }

}
