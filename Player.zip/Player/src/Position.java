public enum Position {


    DEFENDER(0),
    MID_FILDER(1),
    ATTACKER(2);

    private int getNum;

    private String posValue[] = {
            "Defender",
            "Midfilder",
            "Attacker"
    };

    private Position(int num) {
        getNum = num;
    }

    public String toString() {
        return posValue[getNum];
    }

}
