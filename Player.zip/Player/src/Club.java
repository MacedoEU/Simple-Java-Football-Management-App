import java.util.ArrayList;

public class Club {

    private int clubID;
    private String clubName;
    private double money;

    protected ArrayList<Footballer> footballers = new ArrayList<Footballer>();
    protected static ArrayList<Club> clubs = new ArrayList<Club>();

    Club(int clubID, String clubName, double money) {
        setClubID(clubID);
        setClubName(clubName);
        setMoney(money);
    }

    private void setClubID(int clubID) {
        if (clubID >= 1) {
            this.clubID = clubID;
        }
    }

    private void setClubName(String clubName) {
        if (clubName != null) {
            this.clubName = clubName;
        }
    }

    protected void setMoney(double money) {
        this.money = money;
    }

    public int getClubID() {
        return this.clubID;
    }

    public String getClubName() {
        return this.clubName;
    }

    public double getMoney() {
        return this.money;
    }

}
