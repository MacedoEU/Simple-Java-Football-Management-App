import java.util.Scanner;

public class ClubManagement {

    public static void main(String[] args) {
        Menu();
    }

    private static void Menu() {
        Scanner sc = new Scanner(System.in);
        System.out.println("");
        System.out.println("    Club Management");
        System.out.println("-----------------------");
        System.out.println("1. Add a New Footballer");
        System.out.println("2. Add a New Club");
        System.out.println("3. Show all Footballers");
        System.out.println("4. Show all clubs");
        System.out.println("5. Change Player price");
        System.out.println("6. Search Player via ID");
        System.out.println("7. Search Club via ID");
        System.out.println("8. Purchase a Player");
        System.out.println("9. Show Footballers per club");
        System.out.println("10. Exit");
        System.out.println("-------------------------");
        System.out.print("Input: ");
        int choice = sc.nextInt();
        System.out.println("");
        choiceDecsion(choice);
    }

    private static void choiceDecsion(int choice) {

        if (choice == 1) {
            addFootballer();
        }

        else if (choice == 2) {
            addClub();
        }

        else if (choice == 3) {
            showFootballers();
        }

        else if (choice == 4) {
            showClubs();
        }

        else if (choice == 5) {
            changePlayerPrice();
        }

        else if (choice == 6) {
            searchPlayer();
        }

        else if (choice == 7) {
            searchClub();
        }

        else if (choice == 8) {
            purchaseAPlayer();
        }

        else if (choice == 9) {
            showPlayerByClub();
        }

        else if (choice == 10) {
            exit();
        }

        else {
            System.out.println("Invalid data please enter a choice between 1 and 10");
            System.out.println("");
            Menu();
        }
    }

    private static void addFootballer() {

        Scanner sc = new Scanner(System.in);
        System.out.println("Add a Footballer");
        System.out.println("-------------------");
        System.out.print("Please enter in a Footballers name: ");
        String name = sc.next();
        System.out.println("");

        System.out.println("Please enter in " + name + "'s Postion");
        System.out.println("------------------------------------------");
        System.out.println("1. Defender");
        System.out.println("2. Midfilder");
        System.out.println("3. Attacker");
        System.out.println("------------------------------------------");
        System.out.print("Input: ");
        int p = sc.nextInt();
        String position = "";

        if (p == 1 ) {
            position = "defender";
        }
        else if (p == 2) {
            position = "midfilder";
        }
        else if (p == 3) {
            position = "attacker";
        }
        else {
            System.out.println("Invalid data please enter in again");
            System.out.println("");
            addFootballer();
        }

        System.out.println("");
        System.out.print("Please enter in a Footballer's ID: ");
        int id = sc.nextInt();

        if (searchFootballerID(id) == true) {
            System.out.println("Footballer ID exists please enter in another one");
            System.out.println("");
            addFootballer();
        }
        else {
            System.out.println("");
            System.out.print("Please enter in the Footballer's age: ");
            int age = sc.nextInt();
            System.out.println("");

            System.out.print("Please enter in the Footballers price: ");
            double price = sc.nextDouble();
            Footballer f = new Footballer(id, name, age, position, price);
            Footballer.allFootballers.add(f);
            System.out.println("");
            printFootballer(f);
        }
    }

    private static void printFootballer(Footballer f) {
        System.out.println("Footballer has been added");
        System.out.println("--------------------------------------------------");
        System.out.println("Footballer ID: " + f.getFootID() +
                            ", Name: " + f.getName() +
                            ", Age: " +  f.getAge() +
                            ", Position: " + f.getPos() +
                            ", Price: " + f.getPrice()
                );
        System.out.println("--------------------------------------------------");
        System.out.println("");
        Menu();
    }

    private static boolean searchFootballerID(int id) {

        for (int i = 0; i < Footballer.allFootballers.size(); i++) {
            if (Footballer.allFootballers.get(i).getFootID() == id) {
                return true;
            }
        }
        return false;

    }

    private static void addClub() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Add Club");
        System.out.println("---------------");
        System.out.print("Please enter in a Club ID: ");
        int  id = sc.nextInt();

        if (searchClubID(id) == true) {
            System.out.println("");
            System.out.println("Club ID has been taken please choose another one");
            System.out.println("");
            addClub();
        }

        else {
            System.out.println("");
            System.out.print("Please enter in a Club Name: ");
            String name = sc.next();
            System.out.println("");
            System.out.print("Please enter in the Club's Money: ");
            double money = sc.nextDouble();
            Club c = new Club(id, name, money);
            Club.clubs.add(c);
            System.out.println("");
            printClub(c);
        }

    }

    private static void printClub(Club c) {
        System.out.println("Club has been added");
        System.out.println("-------------------------------------------");
        System.out.println("Club ID: " + c.getClubID() + ", Club Name: " + c.getClubName() + ", Club Money: " + c.getMoney());
        System.out.println("-------------------------------------------");
        System.out.println("");
        Menu();
    }

    private static boolean searchClubID(int id) {

        for (int i = 0; i < Club.clubs.size(); i++) {
            if (Club.clubs.get(i).getClubID() == id) {
                return true;
            }
        }
        return false;
    }

    private static void showFootballers() {

        if (Footballer.allFootballers.size() == 0) {
            System.out.println("No footballers are in the Application");
            System.out.println("");
            Menu();
        }

        else {
            System.out.println("All Footballers");
            System.out.println("-------------------------------------------------------");

            for (int i = 0; i < Footballer.allFootballers.size(); i++ ) {
                System.out.println("Footballer ID: "  + Footballer.allFootballers.get(i).getFootID() +
                        ", Name: " + Footballer.allFootballers.get(i).getName() +
                        ", Age: " + Footballer.allFootballers.get(i).getAge() +
                        ", Position: " + Footballer.allFootballers.get(i).getPos() +
                        ", Price: " + Footballer.allFootballers.get(i).getPrice()
                        );
            }
            System.out.println("-------------------------------------------------------");
            System.out.println("");
            Menu();
        }
    }

    private static void showClubs() {

        if (Club.clubs.size() == 0) {
            System.out.println("No Clubs have been added to the application");
            System.out.println("");
            Menu();
        }
        else {
            System.out.println("All Clubs");
            System.out.println("----------------------------------------------------------");

            for (int i = 0; i < Club.clubs.size(); i++) {
                System.out.println("Club ID: " + Club.clubs.get(i).getClubID() +
                                    ", Club Name: " + Club.clubs.get(i).getClubName() +
                                    ", Club Money: " + Club.clubs.get(i).getMoney()
                        );
            }
            System.out.println("----------------------------------------------------------");
            System.out.println("");
            Menu();
        }

    }


    private static void changePlayerPrice() {

        if (Footballer.allFootballers.size() == 0) {
            System.out.println("No Footballers have been added to the Application");
            System.out.println("");
            Menu();
        }

        else {
            Scanner sc = new Scanner(System.in);
            System.out.println("Change Player's ID: ");
            System.out.println("--------------------------");
            System.out.print("Please enter in the Player's ID");
            int id = sc.nextInt();

            if (searchFootballerID(id) == true) {
                System.out.print("Enter in the new price: ");
                double price = sc.nextDouble();
                Footballer f = returnFootballer(id);
                f.setPrice(price);
                System.out.println("Price has been updated till " + f.getPrice());

                System.out.println("");
                Menu();
            }
            else {
                System.out.println("No footballer with that id exists please enter in another ID");
                System.out.println("");
                changePlayerPrice();
            }


        }

    }

    private static Footballer returnFootballer(int id) {

        for (int i = 0; i < Footballer.allFootballers.size(); i++) {
            if (Footballer.allFootballers.get(i).getFootID() == id) {
                return Footballer.allFootballers.get(i);
            }
        }

        return null;

    }

    private static void searchPlayer() {

        Scanner sc = new Scanner(System.in);

        if (Footballer.allFootballers.size() == 0) {
            System.out.println("No Footballers have been added to the Application");
            System.out.println("--------------------------------------------------");
            Menu();
        }

        else {
            System.out.println("Search a footballer via ID");
            System.out.println("--------------------------------");
            System.out.print("Please enter in the Footballer ID: ");
            int id = sc.nextInt();

            if (searchFootballerID(id) == true) {
                Footballer f = returnFootballer(id);
                System.out.println("");
                System.out.println("-----------------------------------------------------------------------------------");
                System.out.println("ID: " + f.getFootID() + ", Name: " + f.getName() + ", Age: " + f.getAge() + ", Position: " + f.getPos() + ", Price: £" + f.getPrice());
                System.out.println("-----------------------------------------------------------------------------------");
                System.out.println("");
                Menu();
            }
            else{
                System.out.println("No Footballer ID has been found please enter in another one");
                System.out.println("");
                searchPlayer();
            }
        }
    }

    private static void searchClub() {

        if (Club.clubs.size() == 0 ) {
            System.out.println("No Clubs have been added to the Application");
            System.out.println("");
            Menu();
        }

        else {
            Scanner sc = new Scanner(System.in);
            System.out.println("Search a Club via Club ID");
            System.out.println("------------------------------");
            System.out.print("Please enter in Club ID");
            int id = sc.nextInt();
            System.out.println("");

            if (searchClubID(id) == true) {
                Club c = returnClub(id);
                System.out.println("Club");
                System.out.println("----------------------------------------");
                System.out.println("Club ID: " + c.getClubID() + ", Club Name: " + c.getClubName() + ", Club Money: " + c.getMoney() );
                System.out.println("----------------------------------------");
                System.out.println("");
                Menu();
            }

            else {
                    System.out.println("No club has been found please try again");
                    System.out.println("");
                    searchClub();
            }

        }

    }

    private static Club returnClub(int id) {
        for (int i = 0; i < Club.clubs.size(); i++) {
            if (Club.clubs.get(i).getClubID() == id) {
                return Club.clubs.get(i);
            }
        }
        return null;
    }

    private static void purchaseAPlayer() {
        if (Club.clubs.size() == 0) {
            System.out.println("No Clubs exist");
            System.out.println("");
            Menu();
        }

        else if(Footballer.allFootballers.size() == 0 ) {
            System.out.println("No Footballers exist");
            System.out.println("");
            Menu();
        }

        else {
            Scanner sc = new Scanner(System.in);
            System.out.println("Purchase a Player");
            System.out.println("-----------------------");
            System.out.println("Input Club ID: ");
            int clubID = sc.nextInt();

            if (searchClubID(clubID) == true) {

                Club club = returnClub(clubID);
                System.out.println("");
                System.out.println(club.getClubName() + " has £" + club.getMoney() + " left");
                System.out.print("Please enter in the Footballer ID: ");
                int footID = sc.nextInt();

                if (searchFootballerID(footID) == true) {
                    Footballer foot = returnFootballer(footID);

                    if (club.getMoney() >= foot.getPrice() && foot.getPurchase() == false) {
                        System.out.println("");
                        System.out.println("Footballer: " + foot.getName() + " Has been purchased");
                        foot.setPurchase(true);
                        club.footballers.add(foot);
                        System.out.println("");
                        Menu();
                    }
                    else {
                        System.out.println("Either the Footballer has  been purchased or the club cant afford the Footballer");
                        System.out.println("");
                        Menu();
                    }

                }


                else {
                    System.out.println("");
                    System.out.println("No footballer with that ID exists");
                    System.out.println("");
                    purchaseAPlayer();
                }


            }
            else {
               System.out.println("No club exists with that ID: ");
               System.out.println("");
               purchaseAPlayer();
            }

        }

    }

    private static void showPlayerByClub() {

        if (Club.clubs.size() == 0) {
            System.out.println("No clubs have been added");
            System.out.println("");
            Menu();
        }

        else {
            Scanner sc = new Scanner(System.in);
            System.out.println("Footballers per club");
            System.out.print("Please enter in the Club ID: ");
            int clubID = sc.nextInt();

            if (searchClubID(clubID) == true) {
                Club club = returnClub(clubID);

                System.out.println("");
                System.out.println("--------------------------------------------");

                for (int i = 0; i < club.footballers.size(); i++) {
                    System.out.println("Footballer ID: " + club.footballers.get(i).getFootID());
                }
                System.out.println("--------------------------------------------");
                System.out.println("");
                Menu();
            }

            else {
                System.out.println("No clubs with that ID exist please try again");
                System.out.println("");
                showPlayerByClub();
            }
        }
    }

    private static void exit() {
    System.out.println("---------------------------------");
    System.out.println("Application closed");
    System.out.println("---------------------------------");
    }
}

